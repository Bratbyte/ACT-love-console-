# ACT LOVE CONSOLE 💚✈️

A romantic aviation-themed terminal web app made for love.

## ✨ Features

- Type commands like `STATUS`, `SEND_LOVE`, `CLEARANCE`, etc.
- Custom ASCII airplane art
- Simulates an aviation console for your special one

## 🚀 How to Use

1. Clone or download this repo
2. Open `index.html` in any browser (mobile or desktop)
3. Type commands into the terminal and watch the love fly

## 💻 Example Commands

```
STATUS
SEND_LOVE
LAUNCH_HEART
CLEARANCE
LOGBOOK
```

## 🛩️ Love Mission Status: CLEAR FOR TAKEOFF
